<?php $this->load->view('admin/include/header'); ?>
<?php $this->load->view('admin/include/header_menu'); 
  ?>
<div class="container-fluid">

<!-- Page Heading -->
<div class="d-sm-flex align-items-center justify-content-between mb-4">
  <h1 class="h3 mb-0 text-gray-800">Dashboard / Edit Products</h1>
  <!-- <button type="button" class=" d-sm-inline-block btn btn-sm btn-grad btn-primary shadow-sm " style="float:right" data-toggle="modal" data-target="#add_area">
  Add Area
</button>
  <a href="<?php echo base_url();?>index.php/View/customer/list_customer" class=" d-sm-inline-block btn btn-sm btn-grad btn-primary shadow-sm"><i class="fas fa-add"></i> List Customers</a> -->
  </div>
<div class="row">

<!-- Area Chart -->
<div class="col-xl-12 col-lg-7">
  <div class="card shadow mb-4">
    <!-- Card Header - Dropdown -->
    <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
      <h6 class="m-0 font-weight-bold text-primary">Edit Products Form</h6>
    </div>
    <!-- Card Body -->
    <div class="card-body">
    <form class="form-horizontal" action="<?php echo base_url();?>Insert/products/products/<?php echo $edit_id; ?>/list_products/list_products " method="post" enctype="multipart/form-data" >
    <?php $profile_edit=$this->Admin_model->table_column('products','id',$edit_id); 
    if(count($profile_edit) > 0)
    {
        foreach($profile_edit as $row_edit)
        { ?>
            <div class="box-body">
        <div class="row">
        <input type="hidden" class="form-control" id="product_category_id" name="category_id">
        </div>
        <div class="row">
        <div class="form-group col-md-6">
            <label for="inputEmail3" class="col-sm-6 control-label">Sub Category  </label>
            <select name="sub_category_id" class="form-control" id="sub_category">
            <?php $profile=$this->Admin_model->table_column('sub_category');
            if(count($profile) > 0)
            {
                foreach($profile as $row)
                { ?>
                    <option value="<?php echo $row['id']; ?>"><?php echo $row['sub_category']; ?></option>
        <?php    }
            }
            ?>
            </select>
        </div>
        <div class="form-group col-md-6">
            <label for="inputEmail3" class="col-sm-6 control-label">Product Name </label>
            <div class="col-sm-12">
            <input type="text" name= "products" id="" class="form-control" id="inputEmail3" <?php echo $row_edit['products']; ?>>
            <input type="hidden" name="status" value="1">
            </div>
        </div>
        </div>
        <div class="form-group row">
            <div class="col-sm-6">
            <label for="inputEmail3" class="col-sm-6 control-label">Product Image </label>
                <input type="file" name="img" class="custom-file-input" id="exampleInputFile" >
                <label class="custom-file-label" for="exampleInputFile">Choose Images</label>
            </div>
            <div class="form-group col-md-6">
            <label for="inputEmail3" class="col-sm-6 control-label ">Overall Price </label>
            <div class="col-sm-12">
            <input type="text" name= "price" id="" class="form-control overall" id="inputEmail3" <?php echo $row_edit['price']; ?>>
           
            </div>
            </div>
        </div>

        <div class="form-group row">
        
            <div class="form-group col-md-6">
            <label for="inputEmail3" class="col-sm-6 control-label ">Discount Price </label>
            <div class="col-sm-12">
            <input type="text" name= "discount" id="" class="form-control discount" id="inputEmail3" <?php echo $row_edit['discount']; ?>>
           
            </div>
        </div>
        <div class="form-group col-md-6">
            <label for="inputEmail3" class="col-sm-6 control-label ">Final Price </label>
            <div class="col-sm-12">
            <input type="text" name= "final_price" id="" class="form-control final" id="inputEmail3" <?php echo $row_edit['final_price']; ?>>
           
            </div>
        </div>
        </div>
        
        <!-- /.box-body -->
        <div class="box-footer">
        <button type="submit" class="btn btn-gradient-green pull-right">Submit</button>
        </div>
 <?php   }
    }
    
    
    ?>
        
        <!-- /.box-footer -->
    </form>
    </div>
  </div>
</div>

</div>

</div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<script src="https://code.jquery.com/jquery-1.12.4.min.js"></script>
<script type="text/javascript"></script>

    <script>
    $(document).on('change','#sub_category',function(){
    var sub_category=$(this).val();
    var base_url = "<?php echo base_url(); ?>";
    $.ajax({
            url: base_url+'Admin/product_category',
            type: 'POST',
            dataType: "json",
            data: "sub_category=" + sub_category ,
            success: function(data) {
                $('#product_category_id').val(data.category);
            }
        });
 });
    </script>

<script>
    $(document).on('keyup','.discount',function(){
        var discount=Number($(this).val());
        var overall=Number($('.overall').val());
        var dis_amount=(overall/100)*discount;
        var final=overall-dis_amount;
        $('.final').val(final);
    });
    </script> 

<?php $this->load->view('admin/include/footer'); ?>
