<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends CI_Controller {
	function __construct(){
        parent:: __construct();
        $this->load->model('Admin_model');
        $this->load->helper('url');
        $this->load->library('session');
    }
	public function index()
	{
		$this->load->view('front/index.php');
    }
    public function View($foldername,$file)
    {
        $this->load->view($foldername.'/'.$file);
	}
	public function administration()
	{
		$this->load->view('Admin/index.php');
	}
	public function View_admin($foldername,$filename,$edit_id=FALSE)
	{
		if($edit_id != FALSE)
		{
			$data['edit_id']=$edit_id;
			$this->load->view('admin/'.$foldername.'/'.$filename.'',$data);
		}
		else{
			$this->load->view('admin/'.$foldername.'/'.$filename);
		}
	}
	public function Insert($tablename, $folder, $current_page, $page)
	{
		$imgname=time().'_'.$_FILES["img"]["name"]; 
            $config['upload_path']='./assets/admin/img'; 
            $config['allowed_types']='png|jpg|jpeg';
            $config['encrypt_name']=FALSE;
            $config['file_name']=$imgname;
            $this->load->library('upload',$config);
            if (!$this->upload->do_upload('img')) {
               $error = array('error' => $this->upload->display_errors());
            } 
            else {
                $data = array('img' => $this->upload->data());
            }
            $file=$this->upload->data();
		$columns = $this->Admin_model->table($tablename);
					for($i=0;$i<count($columns);$i++)
					{
						if($columns[$i]!="id")
						{
						   if($columns[$i]=="date_created") {
								$date = date('Y-m-d');
								$data[$columns[$i]] = $date;
							}
							else if($columns[$i]=="status") {
								$data[$columns[$i]] = '1';
							}
							else if($columns[$i] == "img"){
								$img = $imgname;
								$data[$columns[$i]] = $img;
							}
								else {
								$data[$columns[$i]] = $this->input->post($columns[$i]);
							}
						}
					}
					// if($this->input->post('password')){
					//     $data['password']=sha1($this->input->post('password'));
					// }
					$insert = $this->Admin_model->create($tablename,$data);
					if(isset($insert)){
						redirect('View_admin/'.$folder.'/'.$page.'');
					} else {
						redirect('View_admin/'.$folder.'/'.$current_page.'');
					}
	}
	public function status()
	{
		$id=$this->input->post('id');
		$tablename=$this->input->post('tablename');
		$profile=$this->Admin_model->table_column($tablename,'id',$id);
		foreach($profile as $row)
		{
			$status=$row['status'];
			if($status == 1)
			{
				$data['status'] = 0;
				$where['id'] = $id;
				$this->Admin_model->edit($tablename,$data,$where);
			}
			if($status == 0)
			{
				$data['status'] = 1;
				$where['id']=$id;
				$this->Admin_model->edit($tablename,$data,$where);
			}
		}
	}
	public function Delete($tablename,$foldername,$filename,$delete_id)
	{
		$where['id']=$delete_id;
		$insert=$this->Admin_model->delete($tablename,$delete_id);
		if(isset($insert))
		{
			redirect('View_admin/'.$foldername.'/'.$filename);
		}
		else{
			redirect('View_admin/'.$foldername.'/'.$filename);
		}
	}
	public function Update_all($tablename, $folder, $edit_id, $current_page, $page)
        {
			
			$where = array();
					$columns = $fields['columns'] = $this->Admin_model->table($tablename);
					for($i=0;$i<count($columns);$i++)
					{
						if(($columns[$i]!="id")&&($columns[$i]!="status")&&($columns[$i]!="date_created"))
						{
							if($columns[$i]=="date_modified") {
								$date = date('Y-m-d');
								$data[$columns[$i]] = $date;
							} else{
								$data[$columns[$i]] = $this->input->post($columns[$i]);
							}
						}
					}
				
				
						$where['id'] = $edit_id;
						$update_all = $this->Admin_model->edit($tablename,$data,$where);
					
					
					if(isset($update_all)){
						redirect('View_admin/'.$folder.'/'.$page.'');
					} else {
						redirect('View_admin/'.$folder.'/'.$current_page.'');
					}
		}
	public function product_category()
	{
		$product=$this->input->post('sub_category');
		$data=array();
		$cus_num=$this->Admin_model->table_column('sub_category','id',$product);
		foreach($cus_num as $cus_row){
			$data['category']=$cus_row['category_id'];
		}
		echo json_encode($data);
	}

}
