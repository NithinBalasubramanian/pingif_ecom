<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends CI_Controller {
	function __construct(){
        parent:: __construct();
        $this->load->model('Admin_model');
        $this->load->helper('url');
        $this->load->library('session');
    }
	public function index()
	{
		$this->load->view('front/index');
    }
    public function View($foldername,$file)
    {
        $this->load->view($foldername.'/'.$file);
	}
	public function administration()
	{
		if($this->session->userdata('user_id')){
			$this->load->view('admin/index');
		}else{
			$this->load->view('admin/login');
		}
	}
	public function View_admin($foldername,$filename,$edit_id=FALSE)
	{
		if($this->session->userdata('user_id')){
		if($edit_id != FALSE)
		{
			$data['edit_id']=$edit_id;
			$this->load->view('admin/'.$foldername.'/'.$filename.'',$data);
		}
		else{
			$this->load->view('admin/'.$foldername.'/'.$filename);
		}
		}else{
			redirect('admin/administration');
		}
	}
	public function login()
	{
		$email=$this->input->post('email');
		$password=$this->input->post('password');
		$val_check=$this->Admin_model->table_column('admin','email',$email,'password',$password);
		if(count($val_check)>0){
			foreach($val_check as $row){
				$this->session->set_userdata('user_id',$row['id']);
				redirect('admin/administration');
			}
		}else{
			$this->session->set_flashdata('msg','Incorrect Email or Password');
			redirect('admin/administration');
		}
	}
	public function logout()
	{
		$this->session->unset_userdata('user_id');
		$this->session->sess_destroy();
		redirect('admin/administration');
	}
	public function add_product_admin($tablename,$folder,$pagename,$nextpage)
	{
		$data=array();
		if($_FILES["img"]["name"]){
		$fileExt = pathinfo($_FILES["img"]["name"], PATHINFO_EXTENSION);
		$imgname=time().'_a.'.$fileExt;
            $config['upload_path']='./assets/admin/img/products'; 
            $config['allowed_types']='png|jpg|jpeg';
            $config['encrypt_name']=FALSE;
            $config['file_name']=$imgname;
            $this->load->library('upload',$config);
            if (!$this->upload->do_upload('img')) {
               $error = array('error' => $this->upload->display_errors());
            } 
            else {
                $data = array('img' => $this->upload->data());
			}
			$data['img']=$imgname;
		}
		$data['category_id']=$this->input->post('category_id');
		$data['sub_category_id']=$this->input->post('sub_category_id');
		$data['product']=$this->input->post('product');
		$data['tags']=$this->input->post('tags');
		$data['model']=$this->input->post('model');
		$data['quantity']=$this->input->post('quantity');
		$data['price']=$this->input->post('price');
		$data['discount']=$this->input->post('discount');
		$data['final_price']=$this->input->post('final_price');
		$data['description']=$this->input->post('description');
		$data['status']='1';
		$data['todays_deal']='0';
		$data['express']='0';
		$data['product_by']='admin';
		$data['added_by']=$this->session->userdata('user_id');
		$product_id=$this->Admin_model->create('products',$data);
		$data1=array();
		$colors=$this->input->post('color');
		for($i=0;$i<count($colors);$i++){
			$data1['color']=$colors[$i];
			$data1['product_id']=$product_id;
			if($_FILES["sub_img"]["name"][$i]){
				$fileExt = pathinfo($_FILES["sub_img"]["name"][$i], PATHINFO_EXTENSION);
				$imgname_sub=time().'_a.'.$fileExt;
					$config['upload_path']='./assets/admin/img/sub_products'; 
					$config['allowed_types']='png|jpg|jpeg';
					$config['encrypt_name']=FALSE;
					$config['file_name']=$imgname;
					$this->load->library('upload',$config);
					if (!$this->upload->do_upload('img')) {
					   $error = array('error' => $this->upload->display_errors());
					} 
					else {
						$data = array('img' => $this->upload->data());
					}
					$data1['sub_img']=$imgname_sub;
				}
				$this->Admin_model->create('product_sub',$data1);
		}
		redirect('View_admin/'.$folder.'/'.$pagename.'');
	}
	public function sub_cat()
	{
		$category=$this->input->post('category');
		$output='';
		$output.='<option>Select Sub Category</option>';
		$val=$this->Admin_model->table_column('sub_category','category_id',$category);
		foreach($val as $val_row){
			$output.='<option value='.$val_row['id'].'>'.$val_row['sub_category'].'</option>';
		}
		echo $output;
	}
	public function Insert($tablename, $folder, $current_page, $page)
	{
		$fileExt = pathinfo($_FILES["img"]["name"], PATHINFO_EXTENSION);
		$imgname=time().'_a.'.$fileExt;
            $config['upload_path']='./assets/admin/img'; 
            $config['allowed_types']='png|jpg|jpeg';
            $config['encrypt_name']=FALSE;
            $config['file_name']=$imgname;
            $this->load->library('upload',$config);
            if (!$this->upload->do_upload('img')) {
               $error = array('error' => $this->upload->display_errors());
            } 
            else {
                $data = array('img' => $this->upload->data());
            }
            $file=$this->upload->data();
		$columns = $this->Admin_model->table($tablename);
					for($i=0;$i<count($columns);$i++)
					{
						if($columns[$i]!="id")
						{
						   if($columns[$i]=="date_created") {
								$date = date('Y-m-d');
								$data[$columns[$i]] = $date;
							}
							else if($columns[$i]=="status") {
								$data[$columns[$i]] = '1';
							}
							else if($columns[$i] == "img"){
								$img = $imgname;
								$data[$columns[$i]] = $img;
							}
								else {
								$data[$columns[$i]] = $this->input->post($columns[$i]);
							}
						}
					}
					// if($this->input->post('password')){
					//     $data['password']=sha1($this->input->post('password'));
					// }
					$insert = $this->Admin_model->create($tablename,$data);
					if(isset($insert)){
						redirect('View_admin/'.$folder.'/'.$page.'');
					} else {
						redirect('View_admin/'.$folder.'/'.$current_page.'');
					}
	}
	public function status()
	{
		$id=$this->input->post('id');
		$tablename=$this->input->post('tablename');
		$profile=$this->Admin_model->table_column($tablename,'id',$id);
		foreach($profile as $row)
		{
			$status=$row['status'];
			if($status == 1)
			{
				$data['status'] = 0;
				$where['id'] = $id;
				$this->Admin_model->edit($tablename,$data,$where);
			}
			if($status == 0)
			{
				$data['status'] = 1;
				$where['id']=$id;
				$this->Admin_model->edit($tablename,$data,$where);
			}
		}
	}
	public function express()
	{
		$id=$this->input->post('id');
		$tablename=$this->input->post('tablename');
		$profile=$this->Admin_model->table_column($tablename,'id',$id);
		foreach($profile as $row)
		{
			$express=$row['status'];
			if($express == 1)
			{
				$data['express'] = 0;
				$where['id'] = $id;
				$this->Admin_model->edit($tablename,$data,$where);
			}
			if($express == 0)
			{
				$data['express'] = 1;
				$where['id']=$id;
				$this->Admin_model->edit($tablename,$data,$where);
			}
		}
	}
	public function today()
	{
		$id=$this->input->post('id');
		$tablename=$this->input->post('tablename');
		$profile=$this->Admin_model->table_column($tablename,'id',$id);
		foreach($profile as $row)
		{
			$todays_deal=$row['todays_deal'];
			if($todays_deal == 1)
			{
				$data['todays_deal'] = 0;
				$where['id'] = $id;
				$this->Admin_model->edit($tablename,$data,$where);
			}
			if($todays_deal == 0)
			{
				$data['todays_deal'] = 1;
				$where['id']=$id;
				$this->Admin_model->edit($tablename,$data,$where);
			}
		}
	}
	public function Delete($tablename,$foldername,$filename,$delete_id)
	{
		$where['id']=$delete_id;
		$insert=$this->Admin_model->delete($tablename,$delete_id);
		if(isset($insert))
		{
			redirect('View_admin/'.$foldername.'/'.$filename);
		}
		else{
			redirect('View_admin/'.$foldername.'/'.$filename);
		}
	}
	public function Update_all($tablename, $folder, $edit_id, $current_page, $page)
        {
			if($_FILES["img"]["name"]){
				$fileExt = pathinfo($_FILES["img"]["name"], PATHINFO_EXTENSION);
				$imgname=time().'_a.'.$fileExt;
				$config['upload_path']='./assets/admin/img'; 
				$config['allowed_types']='png|jpg|jpeg';
				$config['encrypt_name']=FALSE;
				$config['file_name']=$imgname;
				$this->load->library('upload',$config);
				if (!$this->upload->do_upload('img')) {
				$error = array('error' => $this->upload->display_errors());
				} 
				else {
					$data = array('img' => $this->upload->data());
				}
			}

			$where = array();
					$columns = $fields['columns'] = $this->Admin_model->table($tablename);
					for($i=0;$i<count($columns);$i++)
					{
						if(($columns[$i]!="id")&&($columns[$i]!="status")&&($columns[$i]!="date_created"))
						{
							if($columns[$i]=="date_modified") {
								$date = date('Y-m-d');
								$data[$columns[$i]] = $date;
							}else if($columns[$i] == "img"){
								$img = $imgname;
								$data[$columns[$i]] = $img;
							} else{
								$data[$columns[$i]] = $this->input->post($columns[$i]);
							}
						}
					}
				
				
						$where['id'] = $edit_id;
						$update_all = $this->Admin_model->edit($tablename,$data,$where);
					
					
					if(isset($update_all)){
						redirect('View_admin/'.$folder.'/'.$page.'');
					} else {
						redirect('View_admin/'.$folder.'/'.$current_page.'');
					}
		}
	public function product_category()
	{
		$product=$this->input->post('sub_category');
		$data=array();
		$cus_num=$this->Admin_model->table_column('sub_category','id',$product);
		foreach($cus_num as $cus_row){
			$data['category']=$cus_row['category_id'];
		}
		echo json_encode($data);
	}

}
