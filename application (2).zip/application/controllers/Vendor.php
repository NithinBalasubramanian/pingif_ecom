<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Vendor extends CI_Controller {
	function __construct(){
        parent:: __construct();
        $this->load->model('Admin_model');
        $this->load->helper('url');
        $this->load->library('session');
    }
	public function index()
	{
		if($this->session->userdata('user_vendor_id')){
			$this->load->view('vendor/index');
		}else{
			$this->load->view('vendor/login');
		}
    }
    public function View_front($foldername,$filename,$edit_id=FALSE)
	{
		if($edit_id != FALSE)
		{
			$data['edit_id']=$edit_id;
			$this->load->view('admin/'.$foldername.'/'.$filename.'',$data);
		}
		else{
			$this->load->view('admin/'.$foldername.'/'.$filename);
		}
	}
	public function View_vendor($foldername,$filename,$edit_id=FALSE)
	{
		if($this->session->userdata('user_vendor_id')){
			if($edit_id != FALSE)
			{
				$data['edit_id']=$edit_id;
				$this->load->view('vendor/'.$foldername.'/'.$filename.'',$data);
			}
			else{
				$this->load->view('vendor/'.$foldername.'/'.$filename);
			}
		}else{
			redirect('vendor');
		}
	}
	public function Add_product_vendor($tablename,$folder,$pagename,$nextpage)
	{
		$data=array();
		if($_FILES["img"]["name"]){
		$fileExt = pathinfo($_FILES["img"]["name"], PATHINFO_EXTENSION);
		$imgname=time().'_a.'.$fileExt;
            $config['upload_path']='./assets/vendor/img/products'; 
            $config['allowed_types']='png|jpg|jpeg';
            $config['encrypt_name']=FALSE;
            $config['file_name']=$imgname;
            $this->load->library('upload',$config);
            if (!$this->upload->do_upload('img')) {
               $error = array('error' => $this->upload->display_errors());
            } 
            else {
                $data = array('img' => $this->upload->data());
			}
			$data['img']=$imgname;
		}
		$data['category_id']=$this->input->post('category_id');
		$data['sub_category_id']=$this->input->post('sub_category_id');
		$data['product']=$this->input->post('product');
		$data['tags']=$this->input->post('tags');
		$data['model']=$this->input->post('model');
		$data['quantity']=$this->input->post('quantity');
		$data['price']=$this->input->post('price');
		$data['discount']=$this->input->post('discount');
		$data['final_price']=$this->input->post('final_price');
		$data['description']=$this->input->post('description');
		$data['status']='0';
		$data['todays_deal']='0';
		$data['express']='0';
		$data['product_by']='vendor';
		$ven_data=$this->session->userdata('user_vendor_id');
		$data['added_by']=$ven_data['user_id'];
		$product_id=$this->Admin_model->create('products',$data);
		$data1=array();
		$colors=$this->input->post('color');
		for($i=0;$i<count($colors);$i++){
			$data1['color']=$colors[$i];
			$data1['product_id']=$product_id;
			if($_FILES["sub_img"]["name"][$i]){
				$fileExt = pathinfo($_FILES["sub_img"]["name"][$i], PATHINFO_EXTENSION);
				$imgname_sub=time().'_a.'.$fileExt;
					$config['upload_path']='./assets/vendor/img/sub_products'; 
					$config['allowed_types']='png|jpg|jpeg';
					$config['encrypt_name']=FALSE;
					$config['file_name']=$imgname;
					$this->load->library('upload',$config);
					if (!$this->upload->do_upload('img')) {
					   $error = array('error' => $this->upload->display_errors());
					} 
					else {
						$data = array('img' => $this->upload->data());
					}
					$data1['sub_img']=$imgname_sub;
				}
				$this->Admin_model->create('product_sub',$data1);
		}
		redirect('View_vendor/'.$folder.'/'.$pagename.'');
	}
	public function login()
	{
		$email=$this->input->post('email');
		$password=$this->input->post('password');
		$val_check=$this->Admin_model->table_column('vendor','email',$email,'password',$password);
		if(count($val_check)>0){
			foreach($val_check as $row){
				$data=array(
					'user_id'=>$row['id'],
					'user_name'=>$row['name'],
				);
				$this->session->set_userdata('user_vendor_id',$data);
				redirect('vendor');
			}
		}else{
			$this->session->set_flashdata('msg','Incorrect Email or Password');
			redirect('vendor');
		}
	}
	public function logout()
	{
		$this->session->unset_userdata('user_vendor_id');
		$this->session->sess_destroy();
		redirect('vendor');
	}
}
?>