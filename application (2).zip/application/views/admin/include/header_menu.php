
<body id="page-top">

  <!-- Page Wrapper -->
  <div id="wrapper">

    <!-- Sidebar -->
    <ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion disp " id="accordionSidebar" >

      <!-- Sidebar - Brand -->
      <a class="sidebar-brand d-flex align-items-center justify-content-center" href="index.html">
        <div class="sidebar-brand-icon">
          PAXXIE
        </div>
        <div class="sidebar-brand-text mx-3">Admin  </div>
      </a>

      <!-- Divider -->
      <hr class="sidebar-divider my-0">

      <!-- Nav Item - Dashboard -->
      <li class="nav-item active">
        <a class="nav-link" href="<?php echo base_url();?>index.php/Admin">
          <i class="fas fa-fw fa-tachometer-alt"></i>
          <span>Dashboard</span></a>
      </li>

      <!-- Divider -->
      <hr class="sidebar-divider">

      <!-- Heading -->
      <div class="sidebar-heading">
        Menu
      </div>
      <!-- <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseone" aria-expanded="true" aria-controls="collapseone">
          <i class="fas fa-user"></i>
          <span>Customer</span>
        </a>
        <div id="collapseone" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">
            <h6 class="collapse-header">Customer Management:</h6>
            <a class="collapse-item" href="<?php echo base_url();?>View/customer/add_customer">Add Customer</a>
            <a class="collapse-item" href="<?php echo base_url();?>View/customer/list_customer">List Customer</a>
          </div>
        </div>
      </li> -->
      <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseone1" aria-expanded="true" aria-controls="collapseone">
          <i class="fas fa-list"></i>
          <span>Product</span>
        </a>
        <div id="collapseone1" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">
            <h6 class="collapse-header">Product Management:</h6>
            <a class="collapse-item" href="<?php echo base_url();?>View_admin/category/list_category">Category</a>
            <a class="collapse-item" href="<?php echo base_url();?>View_admin/sub_category/list_sub_category">Sub Category</a>
            <a class="collapse-item" href="<?php echo base_url();?>View_admin/brands/list_brands"> Brands</a>
            <a class="collapse-item" href="<?php echo base_url();?>View_admin/products/list_products">All Products</a>
          </div>
        </div>
      </li>
      <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseone41" aria-expanded="true" aria-controls="collapseone41">
          <i class="fa fa-user-plus"></i>
          <span>Vendor</span>
        </a>
        <div id="collapseone41" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">
            <h6 class="collapse-header">Vendor Management:</h6>
            <!-- <a class="collapse-item" href="<?php echo base_url();?>View_admin/vendor/add_vendor">Add Vendor</a> -->
            <a class="collapse-item" href="<?php echo base_url();?>View_admin/vendor/list_vendor">List Vendor</a>
          </div>
        </div>
      </li>
      <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseone42" aria-expanded="true" aria-controls="collapseone42">
          <i class="fa fa-usd"></i>
          <span>Orders</span>
        </a>
        <div id="collapseone42" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">
            <h6 class="collapse-header">Orders Management:</h6>
            <!-- <a class="collapse-item" href="<?php echo base_url();?>View_admin/vendor/add_vendor">Add Vendor</a> -->
            <a class="collapse-item" href="<?php echo base_url();?>View_admin/orders/list_orders">List Orders</a>
          </div>
        </div>
      </li>
      <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseone43" aria-expanded="true" aria-controls="collapseone43">
          <i class="fa fa-users"></i>
          <span>Customers</span>
        </a>
        <div id="collapseone43" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">
            <h6 class="collapse-header">Customers Management:</h6>
            <!-- <a class="collapse-item" href="<?php echo base_url();?>View_admin/vendor/add_vendor">Add Vendor</a> -->
            <a class="collapse-item" href="<?php echo base_url();?>View_admin/orders/list_orders">List Customers</a>
          </div>
        </div>
      </li>
      <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseone44" aria-expanded="true" aria-controls="collapseone44">
          <i class="fa fa-cog"></i>
          <span>Settings</span>
        </a>
        <div id="collapseone44" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">
            <h6 class="collapse-header">Settings Management:</h6>
            <!-- <a class="collapse-item" href="<?php echo base_url();?>View_admin/vendor/add_vendor">Add Vendor</a> -->
            <a class="collapse-item" href="<?php echo base_url();?>View_admin/orders/list_orders">General Settings</a>
          </div>
        </div>
      </li>
      <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseone45" aria-expanded="true" aria-controls="collapseone45">
          <i class="fa fa-lock"></i>
          <span>Admin</span>
        </a>
        <div id="collapseone45" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">
            <h6 class="collapse-header">Admin Management:</h6>
            <!-- <a class="collapse-item" href="<?php echo base_url();?>View_admin/vendor/add_vendor">Add Vendor</a> -->
            <a class="collapse-item" href="<?php echo base_url();?>View_admin/admin_profile/view_profile">View Profile</a>
          </div>
        </div>
      </li>
      <!-- <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseone2" aria-expanded="true" aria-controls="collapseone">
          <i class="fas fa-plus"></i>
          <span>Sub Category</span>
        </a>
        <div id="collapseone2" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">
            <h6 class="collapse-header">Sub Category Management:</h6>
            <a class="collapse-item" href="<?php echo base_url();?>View_admin/sub_category/add_sub_category">Add Sub Category</a>
            <a class="collapse-item" href="<?php echo base_url();?>View_admin/sub_category/list_sub_category">List Category</a>
          </div>
        </div>
      </li>
      <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseone3" aria-expanded="true" aria-controls="collapseone">
          <i class="fas fa-plus"></i>
          <span>Brands</span>
        </a>
        <div id="collapseone3" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">
            <h6 class="collapse-header">Brands Management:</h6>
            <a class="collapse-item" href="<?php echo base_url();?>View_admin/brands/add_brands">Add Brands</a>
            <a class="collapse-item" href="<?php echo base_url();?>View_admin/brands/list_brands">List Brands</a>
          </div>
        </div>
      </li>
      <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseone4" aria-expanded="true" aria-controls="collapseone4">
          <i class="fas fa-plus"></i>
          <span>Products</span>
        </a>
        <div id="collapseone4" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">
            <h6 class="collapse-header">Products Management:</h6>
            <a class="collapse-item" href="<?php echo base_url();?>View_admin/products/add_products">Add Products</a>
            <a class="collapse-item" href="<?php echo base_url();?>View_admin/products/list_products">List Products</a>
          </div>
        </div>
      </li> -->
     
      
      <!-- Nav Item - Pages Collapse Menu -->
     
      
            <!-- Divider -->
      <hr class="sidebar-divider">

      <li class="nav-item">
        <a class="nav-link" href="">
          <i class="fas fa-address-book"></i>
          <span> Report</span>
        </a>
      </li>
      <!-- Heading -->
     

      <!-- Sidebar Toggler (Sidebar) -->
      <div class="text-center d-none d-md-inline">
        <button class="rounded-circle border-0" id="sidebarToggle"></button>
      </div>
    </ul>
    <!-- End of Sidebar -->

    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">

      <!-- Main Content -->
      <div id="content">

        <!-- Topbar -->
        <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">

          <!-- Sidebar Toggle (Topbar) -->
          <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
            <i class="fa fa-bars"></i>
          </button>

          <!-- Topbar Search -->
          <!-- <form class="d-none d-sm-inline-block form-inline mr-auto ml-md-3 my-2 my-md-0 mw-100 navbar-search">
            <div class="input-group">
              <input type="text" class="form-control bg-light border-0 small" placeholder="Search for..." aria-label="Search" aria-describedby="basic-addon2">
              <div class="input-group-append">
                <button class="btn btn-primary" type="button">
                  <i class="fas fa-search fa-sm"></i>
                </button>
              </div>
            </div>
          </form> -->

          <!-- Topbar Navbar -->
          <ul class="navbar-nav ml-auto">

            <!-- Nav Item - Search Dropdown (Visible Only XS) -->
            <li class="nav-item dropdown no-arrow d-sm-none">
              <a class="nav-link dropdown-toggle" href="#" id="searchDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <i class="fas fa-search fa-fw"></i>
              </a>
              <!-- Dropdown - Messages -->
              <div class="dropdown-menu dropdown-menu-right p-3 shadow animated--grow-in" aria-labelledby="searchDropdown">
                <form class="form-inline mr-auto w-100 navbar-search">
                  <div class="input-group">
                    <input type="text" class="form-control bg-light border-0 small" placeholder="Search for..." aria-label="Search" aria-describedby="basic-addon2">
                    <div class="input-group-append">
                      <button class="btn btn-primary" type="button">
                        <i class="fas fa-search fa-sm"></i>
                      </button>
                    </div>
                  </div>
                </form>
              </div>
            </li>

            <!-- Nav Item - Alerts -->
           
            <!-- Nav Item - Messages -->
           
            <div class="topbar-divider d-none d-sm-block"></div>

            <!-- Nav Item - User Information -->
            <li class="nav-item dropdown no-arrow">
              <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">                
      <span class="mr-2 d-none d-lg-inline text-gray-600 small">admin</span>
                <img class="img-profile rounded-circle" src="https://source.unsplash.com/QAB-WJcbgJk/60x60">
              </a>
              <!-- Dropdown - User Information -->
              <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in" aria-labelledby="userDropdown">
      <div class="dropdown-item" onclick="disp_profile()">
        <i class="fas fa-user fa-sm fa-fw mr-2 text-gray-400"></i>
        Profile
</div>
                <div class="dropdown-divider"></div>
                <a class="dropdown-item" href="<?php echo base_url(); ?>Admin/logout" >
                  <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>
                  Logout
                </a>
              </div>
            </li>

          </ul>

        </nav>